package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class61 {
    Steal,
    Store,
    Drop;

}
