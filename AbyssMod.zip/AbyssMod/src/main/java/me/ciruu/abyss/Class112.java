package me.ciruu.abyss;

import java.util.ArrayList;
import kotlin.jvm.internal.DefaultConstructorMarker;
import me.ciruu.abyss.Class111;
import me.ciruu.abyss.Class113;
import net.minecraft.client.gui.ScaledResolution;
import org.jetbrains.annotations.NotNull;

/*
 * Exception performing whole class analysis ignored.
 */
public static final class Class112 {
    public final boolean Method1111() {
        return Class111.Method294();
    }

    public final void Method1112(boolean bl) {
        Class111.Method295(bl);
    }

    @NotNull
    public final ArrayList Method1113() {
        return Class111.Method296();
    }

    public final void Method1114(@NotNull ArrayList arrayList) {
        Class111.Method297(arrayList);
    }

    @NotNull
    public final ScaledResolution Method1115() {
        return Class111.Method298();
    }

    public final void Method1116(@NotNull ScaledResolution scaledResolution) {
        Class111.Method299(scaledResolution);
    }

    @NotNull
    public final Class113 Method1117() {
        return Class111.Method300();
    }

    public final void Method1118(@NotNull Class113 class113) {
        Class111.Method301(class113);
    }

    public final boolean Method1119() {
        return Class111.Method302();
    }

    public final void Method1120(boolean bl) {
        Class111.Method303(bl);
    }

    private Class112() {
    }

    public Class112(DefaultConstructorMarker defaultConstructorMarker) {
        this();
    }
}
