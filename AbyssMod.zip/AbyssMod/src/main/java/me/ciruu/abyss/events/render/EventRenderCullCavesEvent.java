package me.ciruu.abyss.events.render;

import me.ciruu.abyss.events.MinecraftEvent;

public class EventRenderCullCavesEvent
extends MinecraftEvent {
}
