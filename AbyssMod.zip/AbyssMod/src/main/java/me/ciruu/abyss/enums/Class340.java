package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class340 {
    None,
    Toggle,
    Always;

}
