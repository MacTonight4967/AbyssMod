package me.ciruu.abyss.events.render;

import me.ciruu.abyss.Class287;
import net.minecraft.util.EnumHandSide;

/*
 * Exception performing whole class analysis ignored.
 */
public static class EventRenderPreFirstPerson
extends Class287 {
    public EventRenderPreFirstPerson(EnumHandSide enumHandSide) {
        super(enumHandSide);
    }
}
