package me.ciruu.abyss;

public class Class350 {
    private int Field2277;

    public Class350(int n) {
        this.Field2277 = n;
    }

    public int Method1535() {
        return this.Field2277;
    }

    public void Method2879(int n) {
        this.Field2277 = n;
    }
}
