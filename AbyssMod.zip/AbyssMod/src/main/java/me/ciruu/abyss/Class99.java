package me.ciruu.abyss;

public class Class99 {
    private String Field2737;
    private String Field2738;

    public Class99(String string) {
        this.Field2737 = string;
    }

    public void Method3346(String[] stringArray) {
    }

    public String Method3347() {
        return this.Field2738;
    }

    public String Method3348() {
        return this.Field2737;
    }

    public boolean Method3349(String[] stringArray) {
        return false;
    }
}
