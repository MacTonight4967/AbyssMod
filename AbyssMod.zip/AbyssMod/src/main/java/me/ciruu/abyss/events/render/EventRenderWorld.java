package me.ciruu.abyss.events.render;

public class EventRenderWorld {
    private float Field2069;

    public EventRenderWorld(float f) {
        this.Field2069 = f;
    }

    public float Method437() {
        return this.Field2069;
    }

    public void Method2499(float f) {
        this.Field2069 = f;
    }
}
