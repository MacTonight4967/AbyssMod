package me.ciruu.abyss;

public interface Class101 {
    public float Method240();

    public void Method241(float var1);

    public float Method242();

    public void Method243(float var1);

    public float Method244();

    public boolean Method245();

    public void Method246(boolean var1);

    public void Method247(int var1, int var2);

    public void Method248(int var1, int var2);

    public void Method249(int var1, int var2, int var3);

    public void Method250(int var1, int var2, int var3);

    public void Method251(int var1, int var2, int var3, long var4);

    public void Method252(char var1, int var2);

    public void Method253(int var1);

    public boolean Method254(int var1, int var2);
}
