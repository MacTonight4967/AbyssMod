package me.ciruu.abyss;

public interface Class205 {
    public void Method1048();

    public void Method1049();

    public void Method1050();

    public void Method1051(boolean var1);
}
