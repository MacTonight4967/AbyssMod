package me.ciruu.abyss;

import me.ciruu.abyss.Class362;
import net.minecraft.network.Packet;

/*
 * Exception performing whole class analysis ignored.
 */
public static class Class361
extends Class362 {
    public Class361(Packet packet) {
        super(packet);
    }
}
