package me.ciruu.abyss;

/*
 * Exception performing whole class analysis ignored.
 */
public static final class Class236 {
    public static final int Field590 = 1;
    public static final int Field591 = 2;
    public static final int Field592 = 4;
    public static final int Field593 = 8;
    public static final int Field594 = 16;
    public static final int Field595 = 32;
    public static final int Field596 = 63;
}
