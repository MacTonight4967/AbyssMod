package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
static enum Class476 {
    DOWN,
    GROUND,
    UP;

}
