package me.ciruu.abyss;

import me.ciruu.abyss.events.MinecraftEvent;

public class Class487
extends MinecraftEvent {
}
