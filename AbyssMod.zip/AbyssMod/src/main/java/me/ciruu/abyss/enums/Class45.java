package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class45 {
    Target,
    Counter,
    Facing;

}
