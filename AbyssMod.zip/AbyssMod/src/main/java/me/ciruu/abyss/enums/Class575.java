package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class575 {
    Jump,
    MiniJump,
    Packet,
    Bypass,
    New,
    Visual,
    Strict;

}
