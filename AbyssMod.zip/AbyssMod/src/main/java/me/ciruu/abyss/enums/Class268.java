package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class268 {
    Outline,
    Box,
    Both;

}
