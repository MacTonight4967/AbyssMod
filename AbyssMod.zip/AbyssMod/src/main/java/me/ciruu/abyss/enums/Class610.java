package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class610 {
    Packet,
    Bucket,
    Anti,
    AAC,
    NCP,
    Avoid;

}
