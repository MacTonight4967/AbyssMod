package me.ciruu.abyss;

import me.ciruu.abyss.Class133;

/*
 * Exception performing whole class analysis ignored.
 */
protected class Class134 {
    public int Field314;
    public int Field315;
    public int Field316;
    public int Field317;
    final Class133 Field3027;

    protected Class134(Class133 class133) {
        this.Field3027 = class133;
    }
}
