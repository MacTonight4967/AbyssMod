package me.ciruu.abyss.events.player;

import me.ciruu.abyss.events.MinecraftEvent;

public class EventPlayerUpdateMoveState
extends MinecraftEvent {
}
