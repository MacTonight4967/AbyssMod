package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class363 {
    PLAIN(0),
    BOLD(1),
    ITALIC(2);

    int Field1206;

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private Class363() {
        void var3_1;
        this.Field1206 = var3_1;
    }
}
