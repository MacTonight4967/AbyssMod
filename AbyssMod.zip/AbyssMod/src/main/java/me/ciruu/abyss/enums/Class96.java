package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class96 {
    Totem,
    Crystal,
    Gapple,
    Obsidian;

}
