package me.ciruu.abyss.events.network;

import me.ciruu.abyss.events.MinecraftEvent;

public class EventNetworkExceptionCaught
extends MinecraftEvent {
}
