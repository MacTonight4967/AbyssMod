package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
private static enum Class348 {
    Auto,
    Manual,
    Next;

}
