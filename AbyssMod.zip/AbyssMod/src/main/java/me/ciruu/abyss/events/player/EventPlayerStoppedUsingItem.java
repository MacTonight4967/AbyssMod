package me.ciruu.abyss.events.player;

import me.ciruu.abyss.events.MinecraftEvent;

public class EventPlayerStoppedUsingItem
extends MinecraftEvent {
}
