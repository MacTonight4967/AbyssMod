package me.ciruu.abyss.events.entity;

import me.ciruu.abyss.events.MinecraftEvent;

public class EventSteerEntity
extends MinecraftEvent {
}
