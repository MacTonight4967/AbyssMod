package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class515 {
    DamageTest,
    Strafe,
    LowHop,
    Boost,
    OnGround,
    Strafe2b,
    GayHop,
    StrafeBoost,
    YPort;

}
