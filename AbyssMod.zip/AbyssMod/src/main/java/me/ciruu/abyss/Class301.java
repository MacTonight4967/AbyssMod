package me.ciruu.abyss;

/*
 * Exception performing whole class analysis ignored.
 */
public static final class Class301 {
    public static final int Field855 = 17;
    public static final int Field856 = 18;
    public static final int Field857 = 33;
    public static final int Field858 = 34;
    public static final int Field859 = 5;
    public static final int Field860 = 6;
    public static final int Field861 = 9;
    public static final int Field862 = 10;
    public static final int Field863 = 20;
    public static final int Field864 = 36;
    public static final int Field865 = 24;
    public static final int Field866 = 40;
    public static final int Field867 = 63;
}
