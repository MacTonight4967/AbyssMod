package me.ciruu.abyss;

import java.util.HashMap;
import net.minecraft.util.EnumFacing;

/*
 * Exception performing whole class analysis ignored.
 */
public static final class Class237 {
    public static final HashMap Field3142 = new HashMap();

    static {
        Field3142.put(EnumFacing.DOWN, 1);
        Field3142.put(EnumFacing.WEST, 16);
        Field3142.put(EnumFacing.NORTH, 4);
        Field3142.put(EnumFacing.SOUTH, 8);
        Field3142.put(EnumFacing.EAST, 32);
        Field3142.put(EnumFacing.UP, 2);
    }
}
