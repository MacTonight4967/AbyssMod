package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class238 {
    None,
    Blocks,
    Timer;

}
