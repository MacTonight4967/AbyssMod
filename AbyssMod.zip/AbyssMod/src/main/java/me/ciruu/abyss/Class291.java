package me.ciruu.abyss;

/*
 * Exception performing whole class analysis ignored.
 */
public static class Class291 {
    private Object Field3185;
    private Object Field3186;

    public Class291(Object object, Object object2) {
        this.Field3185 = object;
        this.Field3186 = object2;
    }

    public Object Method3864() {
        return this.Field3185;
    }

    public Object Method3865() {
        return this.Field3186;
    }

    public void Method3866(Object object) {
        this.Field3185 = object;
    }

    public void Method3867(Object object) {
        this.Field3186 = object;
    }
}
