package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class53 {
    PRE,
    PERI,
    POST;

}
