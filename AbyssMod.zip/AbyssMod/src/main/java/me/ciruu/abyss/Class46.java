package me.ciruu.abyss;

/*
 * Exception performing whole class analysis ignored.
 */
public static class Class46 {
    private final double Field108;
    private final double Field109;
    private final boolean Field110;

    public Class46(double d, double d2, boolean bl) {
        this.Field108 = d;
        this.Field109 = d2;
        this.Field110 = bl;
    }

    public double Method76() {
        return this.Field108;
    }

    public double Method77() {
        return this.Field109;
    }

    public boolean Method78() {
        return this.Field110;
    }
}
