package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class190;

/*
 * Exception performing whole class analysis ignored.
 */
static class Class436 {
    static final int[] Field1454 = new int[Class190.values().length];

    static {
        try {
            Class436.Field1454[Class190.Forward.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class436.Field1454[Class190.Back.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class436.Field1454[Class190.Right.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class436.Field1454[Class190.Left.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class436.Field1454[Class190.None.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
