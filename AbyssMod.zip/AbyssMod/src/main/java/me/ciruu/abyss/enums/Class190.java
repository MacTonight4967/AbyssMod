package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class190 {
    Forward,
    Back,
    Right,
    Left,
    None;

}
