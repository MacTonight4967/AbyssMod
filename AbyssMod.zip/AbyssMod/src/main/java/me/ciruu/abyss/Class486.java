package me.ciruu.abyss;

import me.ciruu.abyss.events.MinecraftEvent;

public class Class486
extends MinecraftEvent {
}
