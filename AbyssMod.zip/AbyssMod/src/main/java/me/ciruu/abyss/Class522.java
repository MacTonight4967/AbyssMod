package me.ciruu.abyss;

import me.ciruu.abyss.events.MinecraftEvent;

public class Class522
extends MinecraftEvent {
}
