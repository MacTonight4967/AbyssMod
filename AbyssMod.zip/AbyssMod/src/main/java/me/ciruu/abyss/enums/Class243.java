package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class243 {
    North,
    South,
    East,
    West;

}
