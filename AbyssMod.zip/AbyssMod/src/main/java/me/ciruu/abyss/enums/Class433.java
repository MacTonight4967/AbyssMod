package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class433 {
    Yes;

}
