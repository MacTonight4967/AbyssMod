package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class184;

public class Class185 {
    public static String Method502(Class184 class184) {
        String string = class184.equals((Object)Class184.WHITE) ? "f" : (class184.equals((Object)Class184.DARK_RED) ? "4" : (class184.equals((Object)Class184.DARK_BLUE) ? "1" : (class184.equals((Object)Class184.DARK_AQUA) ? "3" : (class184.equals((Object)Class184.LIGHT_PURPLE) ? "d" : (class184.equals((Object)Class184.BLACK) ? "0" : (class184.equals((Object)Class184.DARK_GREEN) ? "2" : (class184.equals((Object)Class184.DARK_PURPLE) ? "5" : (class184.equals((Object)Class184.YELLOW) ? "e" : (class184.equals((Object)Class184.RED) ? "c" : (class184.equals((Object)Class184.AQUA) ? "b" : (class184.equals((Object)Class184.GREEN) ? "a" : (class184.equals((Object)Class184.GOLD) ? "6" : (class184.equals((Object)Class184.DARK_GRAY) ? "8" : (class184.equals((Object)Class184.BLUE) ? "9" : (class184.equals((Object)Class184.GRAY) ? "7" : "r")))))))))))))));
        return '\u00a7' + string;
    }
}
