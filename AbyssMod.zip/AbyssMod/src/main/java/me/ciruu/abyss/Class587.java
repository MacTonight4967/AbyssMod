package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class588;
import net.minecraft.util.math.BlockPos;

/*
 * Exception performing whole class analysis ignored.
 */
public static class Class587
extends BlockPos {
    public Class588 Field2392;

    public Class587(int n, int n2, int n3, Class588 class588) {
        super(n, n2, n3);
        this.Field2392 = class588;
    }

    public Class588 getType() {
        return this.Field2392;
    }
}
