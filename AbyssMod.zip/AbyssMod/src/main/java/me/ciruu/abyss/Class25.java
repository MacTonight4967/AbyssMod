package me.ciruu.abyss;

public class Class25 {
    private String Field2859;

    public Class25(String string) {
        this.Field2859 = string;
    }

    public String Method1608() {
        return this.Field2859;
    }

    public void Method3531(String string) {
        this.Field2859 = string;
    }
}
