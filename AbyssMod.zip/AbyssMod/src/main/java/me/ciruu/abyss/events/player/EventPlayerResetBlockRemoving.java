package me.ciruu.abyss.events.player;

import me.ciruu.abyss.events.MinecraftEvent;

public class EventPlayerResetBlockRemoving
extends MinecraftEvent {
}
