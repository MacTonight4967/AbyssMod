package me.ciruu.abyss;

import me.ciruu.abyss.events.MinecraftEvent;

public class Class277
extends MinecraftEvent {
    private final float Field3510;

    public Class277(float f) {
        this.Field3510 = f;
    }

    public float Method4258() {
        return this.Field3510;
    }
}
