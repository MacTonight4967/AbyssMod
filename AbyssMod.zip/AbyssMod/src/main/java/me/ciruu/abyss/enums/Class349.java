package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
private static enum Class349 {
    Timer,
    Tick;

}
