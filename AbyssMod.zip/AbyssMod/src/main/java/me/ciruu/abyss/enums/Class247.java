package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
private static enum Class247 {
    ALL,
    NEW_ONLY,
    OLD_ONLY;

}
