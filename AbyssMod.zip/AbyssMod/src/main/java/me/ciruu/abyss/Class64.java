package me.ciruu.abyss;

import me.ciruu.abyss.enums.Class65;

/*
 * Exception performing whole class analysis ignored.
 */
static class Class64 {
    static final int[] Field159 = new int[Class65.values().length];

    static {
        try {
            Class64.Field159[Class65.Box.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class64.Field159[Class65.Clock.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class64.Field159[Class65.Triangle.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            Class64.Field159[Class65.Butterfly.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
    }
}
