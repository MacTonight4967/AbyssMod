package me.ciruu.abyss.mixin.accessor;

public interface ICPacketPlayer {
    public void setOnGround(boolean var1);

    public void setX(double var1);

    public void setY(double var1);

    public void setZ(double var1);

    public void setYaw(float var1);

    public void setPitch(float var1);
}
