package me.ciruu.abyss.enums;

/*
 * Exception performing whole class analysis ignored.
 */
public static enum Class413 {
    None,
    Place,
    Break,
    Both;

}
