package me.ciruu.abyss;

import org.jetbrains.annotations.NotNull;

/*
 * Exception performing whole class analysis ignored.
 */
public static final class Class553 {
    private int Field2523;
    private int Field2524;
    @NotNull
    private String Field2525;
    private boolean Field2526;

    public final int Method3028() {
        return this.Field2523;
    }

    public final void Method2609(int n) {
        this.Field2523 = n;
    }

    public final int Method3029() {
        return this.Field2524;
    }

    public final void Method2608(int n) {
        this.Field2524 = n;
    }

    @NotNull
    public final String Method3030() {
        return this.Field2525;
    }

    public final void Method2607(@NotNull String string) {
        this.Field2525 = string;
    }

    public final boolean Method3031() {
        return this.Field2526;
    }

    public final void Method2610(boolean bl) {
        this.Field2526 = bl;
    }

    public Class553(int n, int n2, @NotNull String string, boolean bl) {
        this.Field2523 = n;
        this.Field2524 = n2;
        this.Field2525 = string;
        this.Field2526 = bl;
    }
}
